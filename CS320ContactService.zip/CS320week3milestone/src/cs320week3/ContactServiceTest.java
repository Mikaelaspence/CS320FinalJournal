package cs320week3;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    @Test
    public void testAddContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("5555555555", "John", "Smith", "4135555555", "123 Main St");

        contactService.addContact(contact);
        assertEquals(contact, contactService.getContactId("5555555555"));

        // Adding a contact with the same ID should throw an exception
        assertThrows(IllegalArgumentException.class, () ->
                contactService.addContact(new Contact("5555555555", "Sally", "Struthers", "8584848483", "456 Famous St")));
    }

    @Test
    public void testDeleteContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("5555555555", "John", "Smith", "4135555555", "123 Main St");

        contactService.addContact(contact);
        contactService.deleteContact("5555555555");
        assertNull(contactService.getContactId("5555555555"));
    }

    @Test
    public void testUpdateContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("5555555555", "John", "Smith", "4135555555", "123 Main St");

        contactService.addContact(contact);
        contactService.updateContact("5555555556", "Sally", "Struthers", "8584848483", "456 Famous St");

        Contact updatedContact = contactService.getContactId("1234567890");

        assertEquals("Sally", updatedContact.getFirstName());
        assertEquals("Struthers", updatedContact.getLastName());
        assertEquals("8584848483", updatedContact.getPhone());
        assertEquals("456 Famous St", updatedContact.getAddress());

        // Updating a non-existent contact should throw an exception
        assertThrows(IllegalArgumentException.class, () ->
                contactService.updateContact("0987654321", "John", "Smith", "4135555555", "123 Main St"));
    }

    @Test
    public void testGetContactById() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("5555555557", "John", "Smith", "4135555555", "123 Main St");

        contactService.addContact(contact);
        assertEquals(contact, contactService.getContactId("5555555557"));
        assertNull(contactService.getContactId("0987654321"));
    }
}


