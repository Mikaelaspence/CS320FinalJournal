package cs320week3;

//Create class and set variables
public class Contact {
	private String contactId;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	public Contact(String contactId, String firstName, String lastName, String phone, String address) {
		setContactId(contactId);
		setFirstName(firstName);
		setLastName(lastName);
		setPhone(phone);
		setAddress(address);

}

	public String getContactId() {
		return contactId;
	}
	
	//Setting contact Id with parameters
	public void setContactId(String contactId) {
		if (contactId != null && contactId.length() <= 10) {
			this.contactId = contactId;
		}else {
			throw new IllegalArgumentException("Contact ID is invalid");
		}
	}
	
	//Setting first name with parameters
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		if (firstName != null && firstName.length() <= 10) {
			this.firstName = firstName;
		}else {
			throw new IllegalArgumentException("First name must be present and under 10 letters");
		}
	}
	
	//Setting last name with parameters
	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
		if (lastName != null && lastName.length() <=10) {
			this.lastName = lastName;
		}else {
			throw new IllegalArgumentException("Last name cannot be blank or more than 10 letters");
		}
	}
	
	//Setting phone with parameters
	public String getPhone() {
		return phone;
	}
	
	public void setPhone(String phone) {
		if (phone != null && phone.length() == 10) {
			this.phone = phone;
		}else {
			throw new IllegalArgumentException("Phone number must be 10 digits");
		}
	}
	
	//Setting address with parameters 
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		if (address != null && address.length() <= 30) {
			this.address = address;
		}else {
			throw new IllegalArgumentException("Address must be under 30 characters long.");
		}
	}
	
}
	