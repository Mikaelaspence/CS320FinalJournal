package cs320week3;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testValidContactId() {
        // Valid contact ID
        Contact contact = new Contact("1234567890", "John", "Smith", "5555555555", "123 Main St");
        assertEquals("1234567890", contact.getContactId());
    }

    @Test
    public void testInvalidContactId() {
        // Invalid contact ID (more than 10 characters)
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1234567558901", "John", "Smith", "5555555555", "123 Main St"));
    }

    @Test
    public void testValidFirstName() {
        // Valid first name
        Contact contact = new Contact("1234567890", "John", "Smith", "5555555555", "123 Main St");
        assertEquals("John", contact.getFirstName());
    }

    @Test
    public void testInvalidFirstName() {
        // Invalid first name (more than 10 characters)
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1234567890", "JohnJoHannesBurgerSon", "Smith", "5555555555", "123 Main St"));
    }


    @Test
    public void testValidPhone() {
        // Valid phone number
        Contact contact = new Contact("1234567890", "John", "Smith", "5555555555", "123 Main St");
        assertEquals("1234567890", contact.getPhone());
    }

    @Test
    public void testInvalidPhone() {
        // Invalid phone number (not exactly 10 digits)
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1234567890", "John", "Smith", "55555555556", "123 Main St"));
    }
    
    @Test
    public void testValidAddress() {
        // Valid address (within the limit)
        Contact contact = new Contact("1234567890", "John", "Smith", "5555555555", "123 Main St");
        assertEquals("Valid Address", contact.getAddress());
    }

    @Test
    public void testNullAddress() {
        // Invalid address (null)
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1234567890", "John", "Smith", "5555555555", null));
   
    }

    @Test
    public void testTooLongAddress() {
        // Invalid address (more than 30 characters)
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1234567890", "John", "Smith", "5555555555", "245 This Was a Huge Project and I am Dreading the Next Because I Forgot Java Lane"));
    }
}
