package cs320week3;

import java.util.ArrayList;
import java.util.List;

//create ContactService class
public class ContactService {
	private List<Contact> contacts;
	
	public ContactService() {
		this.contacts = new ArrayList<>();
	}

	//Adding contacts
	public void addContact(Contact contact) {
		String contactId = contact.getContactId();
		
		//if contact doesn't exist, add it
		if (!contactExists(contactId)) {
			contacts.add(contact);
		
		//if contact exists, give error message
		}else {
			throw new IllegalArgumentException("Contact name already taken");
		}
	}
	
	//Deleting
	public void deleteContact(String contactId) {
		contacts.removeIf(contact -> contact.getContactId() == contactId);
	}
	
	//Updating contacts
	public void updateContact(String contactId, String firstName, String lastName, String phone, String address) {
		Contact existingContact = getContactId(contactId);
	
		
		if (existingContact != null) {
			if (firstName != null) {
				existingContact.setFirstName(firstName);
			}
			
			if (lastName != null) {
				existingContact.setLastName(lastName);
			}
			
			if (phone != null) {
				existingContact.setPhone(phone);
			}
			
			if (address != null) {
				existingContact.setAddress(address);
			}
			
			//If there is not a contact to update
		}else {
			throw new IllegalArgumentException("Contact with this ID does not exist");
		}
	}
	
	public Contact getContactId(String contactId) {
		for (Contact contact : contacts) {
			if (contact.getContactId() == contactId);{
				return contact;
			}
		}
		return null;
	}
	
	private boolean contactExists(String contactId) {
		for (Contact contact : contacts) {
			if (contact.getContactId() == contactId) {
				return true;
			}
		}
		return false;
	}
}

	

