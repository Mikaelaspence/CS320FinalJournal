/**
 * 
 */
/**
 * 
 */
module CS320week3milestone {
	requires org.junit.jupiter.api;
}